{\rtf1\ansi\ansicpg1252\cocoartf1504\cocoasubrtf830
{\fonttbl\f0\fnil\fcharset0 AtlasGrotesk-Regular;\f1\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;\red222\green55\blue55;}
{\*\expandedcolortbl;;\csgenericrgb\c0\c0\c0;\csgenericrgb\c87059\c21569\c21569;}
{\*\listtable{\list\listtemplateid1\listhybrid{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{disc\}}{\leveltext\leveltemplateid1\'01\uc0\u8226 ;}{\levelnumbers;}\fi-360\li720\lin720 }{\listname ;}\listid1}}
{\*\listoverridetable{\listoverride\listid1\listoverridecount0\ls1}}
\margl1440\margr1440\vieww9020\viewh12480\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\b\fs40 \cf0 Body Archive Donation
\b0 \
\

\b\fs24 Name:\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\b0 \cf2 Janice Park
\b \cf0 \
\
\
Age:
\b0 \
26\
\
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\b \cf0 Date:\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\b0 \cf0 3/18/18
\b \
\
\
What are your strongest physical characteristics?\

\b0 My torso
\b \
\
\
What are your weakest physical characteristics?\

\b0 My eyes
\b \
\
\
Describe your personality in one sentence.\
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\pardirnatural\partightenfactor0

\b0 \cf0 Some girl trying to fix her stubborn personality.
\b \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0
\cf0 \
\
Choose a Hex color to represent yourself.\
\pard\tx560\tx1120\tx1680\tx2240\tx2800\tx3360\tx3920\tx4480\tx5040\tx5600\tx6160\tx6720\pardirnatural\partightenfactor0

\f1\b0 \cf2 DE3737 \cf0 \cb3     
\f0\b \cb1 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0
\cf0 \
\
How would you like each of your digital parts to be handled on the internet (processed, preserved, distributed, or maintained)?\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\b0 \cf0 \
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\sl336\slmult1\pardirnatural\partightenfactor0
\ls1\ilvl0\cf0 {\listtext	\'95	}FACE / FOREHEAD: distributed\
{\listtext	\'95	}NECK / THROAT AREA: maintained\
{\listtext	\'95	}LEFT HAND, RIGHT HAND: preserved\
{\listtext	\'95	}LEFT FOREARM, RIGHT FOREARM: processed\
{\listtext	\'95	}LEFT UPPER-ARM, RIGHT UPPER-ARM: distributed\
{\listtext	\'95	}STOMACH / TORSO: preserved\
{\listtext	\'95	}LEFT SHIN, RIGHT SHIN: maintained\
{\listtext	\'95	}LEFT FOOT, RIGHT FOOT: maintained\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0
\cf0 \
}