{\rtf1\ansi\ansicpg1252\cocoartf1504\cocoasubrtf830
{\fonttbl\f0\fnil\fcharset0 AtlasGrotesk-Regular;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;\red0\green0\blue0;\red0\green0\blue0;
\red0\green93\blue218;}
{\*\expandedcolortbl;;\csgenericrgb\c0\c0\c0;\cssrgb\c0\c0\c0;\csgray\c0\c0;
\csgenericrgb\c0\c36471\c85490;}
{\*\listtable{\list\listtemplateid1\listhybrid{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{disc\}}{\leveltext\leveltemplateid1\'01\uc0\u8226 ;}{\levelnumbers;}\fi-360\li720\lin720 }{\listname ;}\listid1}}
{\*\listoverridetable{\listoverride\listid1\listoverridecount0\ls1}}
\margl1440\margr1440\vieww9020\viewh12480\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\b\fs40 \cf0 Body.Zip Archive Donation
\b0 \
\

\b\fs24 Name:\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\b0 \cf2 MM
\b \cf0 \
\
\
Age:
\b0 \
22\
\
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\b \cf0 Date:\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\b0 \cf0 3/20/18
\b \
\
\
What are your strongest physical characteristics?\

\b0 Left eyebrow
\b \
\
\
What are your weakest physical characteristics?\

\b0 Wrists
\b \
\
\
Describe your personality in one sentence.\

\b0 Bitter and aloof
\b \
\
\
Choose a Hex color to represent yourself.\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\b0 \cf3 \cb4 #\expnd0\expndtw0\kerning0
005DDA \cf5 \cb5     \cf0 \cb1 \kerning1\expnd0\expndtw0 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\b \cf0 \
\
How would you like each of your digital parts to be handled on the internet (processed, preserved, distributed, maintained)?\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\b0 \cf0 \
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\sl336\slmult1\pardirnatural\partightenfactor0
\ls1\ilvl0\cf0 {\listtext	\'95	}FACE / FOREHEAD: preserved\
{\listtext	\'95	}NECK / THROAT AREA: preserved\
{\listtext	\'95	}LEFT HAND, RIGHT HAND: maintained\
{\listtext	\'95	}LEFT FOREARM, RIGHT FOREARM: processed\
{\listtext	\'95	}LEFT UPPER ARM, RIGHT UPPER ARM: distributed\
{\listtext	\'95	}STOMACH / TORSO: processed\
{\listtext	\'95	}LEFT SHIN, RIGHT SHIN: maintained\
{\listtext	\'95	}LEFT FOOT, RIGHT FOOT: distributed\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0
\cf0 \
}