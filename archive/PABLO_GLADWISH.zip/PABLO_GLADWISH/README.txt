{\rtf1\ansi\ansicpg1252\cocoartf1504\cocoasubrtf830
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;\red0\green0\blue255;}
{\*\expandedcolortbl;;\csgenericrgb\c0\c0\c0;\csgenericrgb\c0\c0\c100000;}
{\*\listtable{\list\listtemplateid1\listhybrid{\listlevel\levelnfc23\levelnfcn23\leveljc0\leveljcn0\levelfollow0\levelstartat1\levelspace360\levelindent0{\*\levelmarker \{disc\}}{\leveltext\leveltemplateid1\'01\uc0\u8226 ;}{\levelnumbers;}\fi-360\li720\lin720 }{\listname ;}\listid1}}
{\*\listoverridetable{\listoverride\listid1\listoverridecount0\ls1}}
\margl1440\margr1440\vieww9020\viewh12480\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\b\fs40 \cf0 Body.Zip Archive Donation
\b0 \
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\b\fs24 \cf0 Name:\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\b0 \cf2 Pablo, Gutierrez-Gladwish
\b \cf0 \
\
\
Age:
\b0 \
21\
\
\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\b \cf0 Date:\

\b0 3/19/18
\b \
\
\
What are your strongest physical characteristics?\

\b0 legs
\b \
\
\
What are your weakest physical characteristics?\

\b0 upper arm
\b \
\
\
Describe your personality in one sentence.\

\b0 Reserved.
\b \
\
\
Choose a Hex color to represent yourself.\

\b0 #0000ff  \cb3     
\b \cb1 \
\
\
How would you like each of your digital parts to be handled on the internet (processed, preserved, distributed, maintained)?\

\b0 \
\pard\tx220\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\li720\fi-720\sl336\slmult1\pardirnatural\partightenfactor0
\ls1\ilvl0\cf0 {\listtext	\'95	}FACE / FOREHEAD: maintained\
{\listtext	\'95	}NECK / THROAT AREA: processed\
{\listtext	\'95	}LEFT HAND, RIGHT HAND: distributed\
{\listtext	\'95	}LEFT FOREARM, RIGHT FOREARM: processed\
{\listtext	\'95	}LEFT UPPER ARM, RIGHT UPPER ARM: processed\
{\listtext	\'95	}STOMACH / TORSO: maintained\
{\listtext	\'95	}LEFT SHIN, RIGHT SHIN: processed\
{\listtext	\'95	}LEFT FOOT, RIGHT FOOT: distributed\
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0
\cf0 \
\
}